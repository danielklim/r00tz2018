<?php

namespace Drupal\Core\Config;

/**
 * Exception thrown when a config import fails.
 */
class ConfigImporterException extends ConfigException {}
