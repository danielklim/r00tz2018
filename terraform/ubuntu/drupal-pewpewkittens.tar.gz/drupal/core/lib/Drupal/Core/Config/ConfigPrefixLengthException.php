<?php

namespace Drupal\Core\Config;

/**
 * Exception thrown when the config prefix length is exceeded.
 */
class ConfigPrefixLengthException extends ConfigException {}
