<?php

namespace Drupal\Core\Config\Schema;

/**
 * Configuration property to ignore.
 */
class Ignore extends Element {

}
