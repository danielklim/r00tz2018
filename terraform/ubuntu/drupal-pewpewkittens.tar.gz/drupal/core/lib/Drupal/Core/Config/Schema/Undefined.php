<?php

namespace Drupal\Core\Config\Schema;

/**
 * Undefined configuration element.
 */
class Undefined extends Element {

}
