<?php

namespace Drupal\Core\Extension;

/**
 * Exception thrown when the extension's name length exceeds the allowed maximum.
 */
class ExtensionNameLengthException extends \Exception {}
